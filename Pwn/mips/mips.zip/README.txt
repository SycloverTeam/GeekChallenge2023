本题是一道异架构Pwn，调试需要依赖qemu

启动容器：docker-compose up
启动后的题目位于端口2333

本地调试参考：https://binlep.github.io/old_blog_01/2020/03/20/%E3%80%90Pwn%20%E7%AC%94%E8%AE%B0%E3%80%91%E8%B7%A8%E5%B9%B3%E5%8F%B0%E6%9E%B6%E6%9E%84%E7%9A%84%E7%8E%AF%E5%A2%83%E9%85%8D%E7%BD%AE%E4%B8%8E%E8%B0%83%E8%AF%95/